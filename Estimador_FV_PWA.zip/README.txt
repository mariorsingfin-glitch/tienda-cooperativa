ESTIMADOR FV - PWA

1. Suba todos estos archivos juntos a un hosting HTTPS.
2. Abra la URL desde Chrome en Android.
3. Menú > Agregar a pantalla de inicio / Instalar aplicación.
4. Luego funcionará también sin conexión.

Para probar en una computadora:
- Ejecute un servidor local dentro de esta carpeta:
  python -m http.server 8000
- Abra http://localhost:8000

Nota: abrir index.html directamente permite usar la calculadora, pero la instalación PWA y el modo offline requieren HTTPS o localhost.
